FactoryGirl.define do
  factory :visitor do
    email "MyString"
  end
end
